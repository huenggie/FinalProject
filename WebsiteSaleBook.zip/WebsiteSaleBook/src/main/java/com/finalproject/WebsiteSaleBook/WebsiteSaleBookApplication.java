package com.finalproject.WebsiteSaleBook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsiteSaleBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsiteSaleBookApplication.class, args);
	}

}
